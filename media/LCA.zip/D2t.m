function y = D2t(x)
y = zeros(2,1);
y(1) = x(1)+x(3);
y(2) = x(2)+x(3);
