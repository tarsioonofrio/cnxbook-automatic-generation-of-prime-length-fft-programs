function y = D2(x)
y = zeros(3,1);
y(1) = x(1);
y(2) = x(2);
y(3) = x(1) + x(2);
