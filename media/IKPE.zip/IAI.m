function y = IAI(A,r,c,m,n,x)
% y = (I(m) kron A kron I(n))x
% r : number of rows of A
% c : number of columns of A
v = 0:n:n*(r-1);
u = 0:n:n*(c-1);
for i = 0:m-1
   for j = 0:n-1
      y(v+i*r*n+j+1) = A * x(u+i*c*n+j+1);
   end
end
